import React, { useState, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, SafeAreaView, Image, Alert, ScrollView, ActivityIndicator } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import { detectCar, getExpectedAngle, PHOTO_CONFIG, CarAngle, DetectionResult } from '@/utils/carDetection';
import { compressImage, COMPRESSION_PRESETS } from '@/utils/imageCompression';
import { analyzeCarDamageWithGemini } from '@/utils/geminiAnalysis';
import { uploadImage, startInspection } from '@/utils/api';

// Simple UUID v4 implementation without crypto
function generateUUID(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

const TOTAL_PHOTOS = 9;

export default function PhotoCaptureScreen() {
  const router = useRouter();
  const { carModel } = useLocalSearchParams();
  const [permission, requestPermission] = useCameraPermissions();
  const cameraRef = useRef<any>(null);

  const [photos, setPhotos] = useState<{ uri: string; name: string; compressed: any; damageAnalysis?: any }[]>([]);
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [showCamera, setShowCamera] = useState(false);
  const [isDetecting, setIsDetecting] = useState(false);
  const [detection, setDetection] = useState<DetectionResult | null>(null);
  const [isAnalyzingDamage, setIsAnalyzingDamage] = useState(false);

  useEffect(() => {
    requestPermission();
  }, []);

  const loadPhotos = async () => {
    // Not needed - just in memory
  };

  const savePhotos = async (updatedPhotos: typeof photos) => {
    // Not storing anywhere
  };

  const processPhoto = async (sourceUri: string, photoIndex: number, detectionResult: DetectionResult) => {
    try {
      // Compress the image using Android MagicWheels style (512KB, 500x500)
      const compressed = await compressImage(
        sourceUri,
        512, // Target size in KB
        500  // Max dimension (500x500)
      );

      console.log(`📸 Photo ${photoIndex + 1} compressed:`, {
        original: `${(compressed.originalSize / 1024).toFixed(2)}KB`,
        compressed: `${(compressed.compressedSize / 1024).toFixed(2)}KB`,
        ratio: `${(compressed.compressionRatio * 100).toFixed(1)}%`,
      });

      return compressed;
    } catch (error) {
      console.log('Error compressing photo:', error);
      throw error;
    }
  };

  const analyzeDamage = async (imageUri: string) => {
    try {
      setIsAnalyzingDamage(true);
      console.log('🔍 Analyzing car for damage using Gemini AI...');
      
      const damageAnalysis = await analyzeCarDamageWithGemini(imageUri);
      
      console.log('📊 Damage Analysis Result:', damageAnalysis);
      
      // Show damage analysis results
      if (!damageAnalysis.imageComplete) {
        Alert.alert(
          '⚠️ Incomplete Image',
          `Please upload a complete car image.\n\n${damageAnalysis.completenessNote || 'Make sure the entire car is visible in the frame.'}`
        );
        return null;
      }

      if (damageAnalysis.hasDamage) {
        Alert.alert(
          `⚠️ Damage Detected (${damageAnalysis.severity.toUpperCase()})`,
          `Type: ${damageAnalysis.damageType}\n\nDescription: ${damageAnalysis.description}\n\nRecommendations:\n${damageAnalysis.recommendations.join('\n')}`
        );
      } else {
        Alert.alert(
          '✅ No Damage Detected',
          'The car appears to be in good condition with no visible damage.'
        );
      }

      return damageAnalysis;
    } catch (error) {
      console.error('Damage analysis error:', error);
      Alert.alert(
        'Analysis Error',
        error instanceof Error ? error.message : 'Failed to analyze image for damage'
      );
      return null;
    } finally {
      setIsAnalyzingDamage(false);
    }
  };

  const handleTakePhoto = async () => {
    if (cameraRef.current) {
      try {
        setIsDetecting(true);
        const photo = await cameraRef.current.takePictureAsync({
          quality: 0.8,
        });
        
        // Run comprehensive detection
        const expectedAngle = getExpectedAngle(currentPhotoIndex);
        const result = await detectCar(photo.uri, expectedAngle);
        
        setDetection(result);
        
        // Check if photo is accepted
        if (!result.isAccepted) {
          setIsDetecting(false);
          return;
        }
        
        // Compress the photo
        const compressed = await processPhoto(photo.uri, currentPhotoIndex, result);
        
        // Analyze for damage using Gemini AI
        const damageAnalysis = await analyzeDamage(photo.uri);
        
        const updatedPhotos = [...photos];
        updatedPhotos[currentPhotoIndex] = {
          uri: photo.uri,
          name: PHOTO_CONFIG[currentPhotoIndex].label,
          compressed,
          damageAnalysis,
        };
        setPhotos(updatedPhotos);
        setShowCamera(false);
        setDetection(null);

        Alert.alert('✓ Photo Captured', `Photo ${currentPhotoIndex + 1} captured and analyzed successfully!`);

        if (currentPhotoIndex < TOTAL_PHOTOS - 1) {
          setCurrentPhotoIndex(currentPhotoIndex + 1);
        }
      } catch (error) {
        console.log('Photo capture error:', error);
        Alert.alert('Error', `Failed to take photo: ${error instanceof Error ? error.message : 'Unknown error'}`);
      } finally {
        setIsDetecting(false);
      }
    }
  };

  const handleOpenCamera = () => {
    if (permission?.granted) {
      setShowCamera(true);
    } else {
      Alert.alert('Permission', 'Camera permission is required');
    }
  };

  const handlePickFromGallery = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: 'images' as any,
        allowsEditing: false,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled) {
        setIsDetecting(true);
        
        // Run comprehensive detection
        const expectedAngle = getExpectedAngle(currentPhotoIndex);
        const detectionResult = await detectCar(result.assets[0].uri, expectedAngle);
        
        setDetection(detectionResult);
        
        if (!detectionResult.isAccepted) {
          setIsDetecting(false);
          return;
        }
        
        const compressed = await processPhoto(result.assets[0].uri, currentPhotoIndex, detectionResult);
        
        // Analyze for damage using Gemini AI
        const damageAnalysis = await analyzeDamage(result.assets[0].uri);
        
        const updatedPhotos = [...photos];
        updatedPhotos[currentPhotoIndex] = {
          uri: result.assets[0].uri,
          name: PHOTO_CONFIG[currentPhotoIndex].label,
          compressed,
          damageAnalysis,
        };
        setPhotos(updatedPhotos);
        await savePhotos(updatedPhotos);
        setDetection(null);

        Alert.alert('✓ Photo Selected', `Photo ${currentPhotoIndex + 1} selected and analyzed successfully!`);

        if (currentPhotoIndex < TOTAL_PHOTOS - 1) {
          setCurrentPhotoIndex(currentPhotoIndex + 1);
        }
        
        setIsDetecting(false);
      }
    } catch (error) {
      console.log('Gallery pick error:', error);
      Alert.alert('Error', `Failed to pick image: ${error instanceof Error ? error.message : 'Unknown error'}`);
      setIsDetecting(false);
    }
  };

  const handleRetakePhoto = async (index: number) => {
    const updatedPhotos = [...photos];
    updatedPhotos[index] = { uri: '', name: PHOTO_CONFIG[index].label, compressed: null };
    setPhotos(updatedPhotos);
    setCurrentPhotoIndex(index);
    setDetection(null);
  };

  const handleSubmit = async () => {
    const photosWithUri = photos.filter(p => p.uri);
    if (photosWithUri.length < TOTAL_PHOTOS) {
      Alert.alert('Incomplete', `Please capture all ${TOTAL_PHOTOS} photos`);
      return;
    }

    try {
      setIsAnalyzingDamage(true);
      let totalOriginal = 0;
      let totalCompressed = 0;
      let damageCount = 0;
      let maxSeverity = 'none';
      let inspectionId: number | null = null;
      let backendUploadSuccess = 0;
      let backendUploadFailed = 0;

      // Backend-only upload
      const severityLevels: Record<string, number> = { none: 0, minor: 1, moderate: 2, severe: 3 };

      // Start inspection on backend
      try {
        console.log('🔄 Starting inspection on backend...');
        const inspection = await startInspection(1); // Default user ID
        inspectionId = inspection.inspection_id;
        console.log('✅ Backend inspection started:', inspectionId);
      } catch (error) {
        console.error('❌ Backend error:', error);
        Alert.alert('Backend Error', 'Failed to start inspection. Make sure backend server is running.');
        setIsAnalyzingDamage(false);
        return;
      }

      // Upload all photos to backend
      for (let i = 0; i < photosWithUri.length; i++) {
        const photo = photosWithUri[i];
        if (photo.compressed) {
          totalOriginal += photo.compressed.originalSize;
          totalCompressed += photo.compressed.compressedSize;

          // Count damage and track severity
          if (photo.damageAnalysis?.hasDamage) {
            damageCount++;
            const severity = photo.damageAnalysis.severity || 'minor';
            const severityVal = severityLevels[severity] || 0;
            const maxSeverityVal = severityLevels[maxSeverity] || 0;
            if (severityVal > maxSeverityVal) {
              maxSeverity = severity;
            }
          }

          // Upload to backend
          try {
            const imageType = PHOTO_CONFIG[i].name.toLowerCase().replace(/\s+/g, '_');
            const result = await uploadImage(inspectionId, imageType, photo.compressed.uri || photo.uri);
            console.log(`✅ Uploaded image ${i + 1} to backend`);
            backendUploadSuccess++;
          } catch (error) {
            console.log(`❌ Failed to upload image ${i + 1}:`, error);
            backendUploadFailed++;
          }
        }
      }

      const savedSpace = totalOriginal - totalCompressed;
      const savedPercent = ((savedSpace / totalOriginal) * 100).toFixed(1);

      let successMessage = `✅ Success!\n\n📱 Images Stored to Room Database\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nAll ${TOTAL_PHOTOS} photos have been saved to your local Room database.\n\n📊 Compression Statistics:\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nOriginal: ${(totalOriginal / 1024 / 1024).toFixed(2)}MB\nCompressed: ${(totalCompressed / 1024 / 1024).toFixed(2)}MB\nSaved: ${(savedSpace / 1024 / 1024).toFixed(2)}MB (${savedPercent}%)\n\n🔍 Inspection Details:\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nInspection ID: ${inspectionId}\nDamage found: ${damageCount} photos\nMax Severity: ${maxSeverity.toUpperCase()}\n\n📤 Backend Upload Results:\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n✅ ${backendUploadSuccess} images uploaded\n❌ ${backendUploadFailed} images failed`;

      Alert.alert(
        '✅ Images Stored to Room Database',
        successMessage,
        [
          {
            text: 'OK',
            onPress: () => router.replace('/cars'),
          },
        ]
      );
    } catch (error) {
      console.error('❌ Error uploading photos:', error);
      Alert.alert(
        'Upload Error',
        error instanceof Error ? error.message : 'Failed to upload photos to backend'
      );
    } finally {
      setIsAnalyzingDamage(false);
    }
  };

  if (showCamera && permission?.granted) {
    const isSuccess = detection?.isAccepted;
    const isFailed = detection && !detection.isAccepted;
    
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.cameraHeader}>
          <Text style={styles.cameraTitle}>
            Photo {currentPhotoIndex + 1} of {TOTAL_PHOTOS}
          </Text>
          <Text style={styles.photoLabel}>{PHOTO_CONFIG[currentPhotoIndex].label}</Text>
          <Text style={styles.expectedAngleLabel}>
            Expected: {PHOTO_CONFIG[currentPhotoIndex].expectedAngle}
          </Text>
        </View>

        <CameraView
          ref={cameraRef}
          style={styles.camera}
          facing="back"
        />

        {detection && (
          <View style={[styles.feedbackBox, isSuccess ? styles.feedbackSuccess : styles.feedbackError]}>
            <Text style={styles.feedbackHint}>{detection.hint}</Text>
            {detection.totalScore > 0 && (
              <View style={styles.scoreBreakdown}>
                <Text style={styles.scoreText}>Score: {detection.totalScore.toFixed(0)}/100</Text>
                <View style={styles.scoreDetails}>
                  <Text style={styles.scoreDetail}>Angle: {detection.angleScore.toFixed(0)}</Text>
                  {detection.framing && (
                    <Text style={styles.scoreDetail}>Framing: {detection.framing.score.toFixed(0)}</Text>
                  )}
                  {detection.lighting && (
                    <Text style={styles.scoreDetail}>Lighting: {detection.lighting.score.toFixed(0)}</Text>
                  )}
                  {detection.quality && (
                    <Text style={styles.scoreDetail}>Quality: {detection.quality.score.toFixed(0)}</Text>
                  )}
                </View>
              </View>
            )}
          </View>
        )}

        {isDetecting && (
          <View style={styles.loadingOverlay}>
            <ActivityIndicator size="large" color="#fff" />
            <Text style={styles.loadingText}>Analyzing photo...</Text>
          </View>
        )}

        <View style={styles.cameraControls}>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => {
              setShowCamera(false);
              setDetection(null);
            }}
            disabled={isDetecting}
          >
            <Text style={styles.closeButtonText}>✕</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.captureButton, isDetecting && styles.captureButtonDisabled]}
            onPress={handleTakePhoto}
            disabled={isDetecting}
          >
            <View style={styles.captureInner} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.galleryButton}
            onPress={handlePickFromGallery}
            disabled={isDetecting}
          >
            <Text style={styles.galleryButtonText}>Gallery</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Upload {carModel} Photos</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView style={styles.content}>
        <View style={styles.photoGrid}>
          {Array.from({ length: TOTAL_PHOTOS }).map((_, index) => {
            const photo = photos[index];
            const isActive = currentPhotoIndex === index;
            const isCompleted = photo?.uri;

            return (
              <View
                key={index}
                style={[
                  styles.photoItem,
                  isActive && styles.photoItemActive,
                  isCompleted && styles.photoItemCompleted,
                ]}
              >
                {isCompleted ? (
                  <>
                    <Image
                      source={{ uri: photo.uri }}
                      style={styles.photoImage}
                    />
                    <TouchableOpacity
                      style={styles.retakeButton}
                      onPress={() => handleRetakePhoto(index)}
                    >
                      <Text style={styles.retakeButtonText}>Retake</Text>
                    </TouchableOpacity>
                  </>
                ) : (
                  <View style={styles.emptyPhoto}>
                    <Text style={styles.photoNumber}>{index + 1}</Text>
                    <Text style={styles.photoSubtext}>{PHOTO_CONFIG[index].label}</Text>
                    <Text style={styles.angleSubtext}>{PHOTO_CONFIG[index].expectedAngle}</Text>
                  </View>
                )}
              </View>
            );
          })}
        </View>
      </ScrollView>

      {photos[currentPhotoIndex]?.uri === undefined || photos[currentPhotoIndex]?.uri === '' ? (
        <View style={styles.actionButtons}>
          <TouchableOpacity
            style={styles.cameraActionButton}
            onPress={handleOpenCamera}
          >
            <Text style={styles.actionButtonText}>📷 Take Photo</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.cameraActionButton, styles.galleryActionButton]}
            onPress={handlePickFromGallery}
          >
            <Text style={styles.actionButtonText}>🖼 From Gallery</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View style={styles.actionButtons}>
          <TouchableOpacity
            style={styles.nextButton}
            onPress={() => {
              if (currentPhotoIndex < TOTAL_PHOTOS - 1) {
                setCurrentPhotoIndex(currentPhotoIndex + 1);
              }
            }}
          >
            <Text style={styles.actionButtonText}>Next</Text>
          </TouchableOpacity>
          {photos.length === TOTAL_PHOTOS && photos.every(p => p.uri) && (
            <TouchableOpacity
              style={styles.submitButton}
              onPress={handleSubmit}
            >
              <Text style={styles.submitButtonText}>Submit All Photos</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  backButton: {
    paddingHorizontal: 8,
    paddingVertical: 6,
  },
  backButtonText: {
    fontSize: 14,
    color: '#007AFF',
    fontWeight: '600',
  },
  placeholder: {
    width: 60,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: '#000',
    flex: 1,
    textAlign: 'center',
  },
  content: {
    flex: 1,
    paddingHorizontal: 12,
    paddingVertical: 16,
  },
  photoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    justifyContent: 'space-between',
  },
  photoItem: {
    width: '30%',
    aspectRatio: 1,
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
    borderWidth: 2,
    borderColor: '#e0e0e0',
    overflow: 'hidden',
  },
  photoItemActive: {
    borderColor: '#007AFF',
    borderWidth: 3,
  },
  photoItemCompleted: {
    borderColor: '#34C759',
  },
  emptyPhoto: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f9f9f9',
  },
  photoNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ccc',
  },
  photoSubtext: {
    fontSize: 10,
    color: '#999',
    marginTop: 4,
    textAlign: 'center',
  },
  angleSubtext: {
    fontSize: 8,
    color: '#bbb',
    marginTop: 2,
    textAlign: 'center',
  },
  photoImage: {
    flex: 1,
    width: '100%',
  },
  retakeButton: {
    position: 'absolute',
    bottom: 4,
    right: 4,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  retakeButtonText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: '600',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  cameraActionButton: {
    flex: 1,
    backgroundColor: '#007AFF',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  galleryActionButton: {
    backgroundColor: '#5AC8FA',
  },
  nextButton: {
    flex: 1,
    backgroundColor: '#007AFF',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  submitButton: {
    flex: 1,
    backgroundColor: '#34C759',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  submitButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  cameraHeader: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#000',
  },
  cameraTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
  },
  photoLabel: {
    fontSize: 14,
    color: '#ccc',
    marginTop: 4,
  },
  expectedAngleLabel: {
    fontSize: 12,
    color: '#999',
    marginTop: 2,
  },
  camera: {
    flex: 1,
  },
  feedbackBox: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    alignItems: 'center',
  },
  feedbackSuccess: {
    backgroundColor: '#34C759',
  },
  feedbackError: {
    backgroundColor: '#FF3B30',
  },
  feedbackHint: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  scoreBreakdown: {
    marginTop: 8,
    alignItems: 'center',
  },
  scoreText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  scoreDetails: {
    flexDirection: 'row',
    marginTop: 4,
    gap: 8,
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  scoreDetail: {
    color: 'rgba(255, 255, 255, 0.9)',
    fontSize: 11,
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#fff',
    marginTop: 12,
    fontSize: 14,
  },
  cameraControls: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingVertical: 20,
    paddingBottom: 30,
    backgroundColor: '#000',
  },
  closeButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeButtonText: {
    fontSize: 24,
    color: '#fff',
  },
  captureButton: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 4,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  captureButtonDisabled: {
    opacity: 0.6,
  },
  captureInner: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#fff',
  },
  galleryButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  galleryButtonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
});
