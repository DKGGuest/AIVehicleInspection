import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, SafeAreaView } from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '@/contexts/auth-context';

const CAR_MODELS = [
  { id: '1', name: 'Sedan', description: 'Standard 4-seat sedan' },
  { id: '2', name: 'SUV', description: 'Spacious SUV for comfort' },
  { id: '3', name: 'Hatchback', description: 'Compact hatchback' },
  { id: '4', name: 'Luxury', description: 'Premium luxury vehicle' },
  { id: '5', name: 'Van', description: 'Multi-passenger van' },
];

export default function CarsScreen() {
  const router = useRouter();
  const { logout } = useAuth();
  const [selectedModel, setSelectedModel] = useState<string | null>(null);

  const handleSelectCar = (carId: string) => {
    setSelectedModel(carId);
    router.push({
      pathname: '/photos',
      params: { carModel: CAR_MODELS.find(c => c.id === carId)?.name || '' },
    });
  };

  const handleLogout = () => {
    logout();
    router.replace('/login');
  };

  const renderCarModel = ({ item }: { item: typeof CAR_MODELS[0] }) => (
    <TouchableOpacity 
      style={styles.carCard}
      onPress={() => handleSelectCar(item.id)}
    >
      <View style={styles.carContent}>
        <Text style={styles.carName}>{item.name}</Text>
        <Text style={styles.carDescription}>{item.description}</Text>
      </View>
      <View style={styles.carArrow}>
        <Text style={styles.arrow}>→</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Select Car Model</Text>
        <TouchableOpacity 
          style={styles.logoutButton}
          onPress={handleLogout}
        >
          <Text style={styles.logoutText}>Logout</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={CAR_MODELS}
        renderItem={renderCarModel}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContainer}
        scrollEnabled={true}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
  },
  logoutButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  logoutText: {
    fontSize: 12,
    color: '#666',
    fontWeight: '500',
  },
  listContainer: {
    padding: 16,
    gap: 12,
  },
  carCard: {
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',

  },
  carContent: {
    flex: 1,
  },
  carName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
    marginBottom: 4,
  },
  carDescription: {
    fontSize: 14,
    color: '#666',
  },
  carArrow: {
    marginLeft: 8,
  },
  arrow: {
    fontSize: 20,
    color: '#007AFF',
    fontWeight: '300',
  },
});
