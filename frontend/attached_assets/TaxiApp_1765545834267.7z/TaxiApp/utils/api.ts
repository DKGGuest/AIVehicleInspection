// API service - Connected to FastAPI Backend
// Hybrid approach: Local AsyncStorage + Backend Server
// See: utils/database.ts for local database operations

import * as FileSystem from 'expo-file-system';

// Backend API Configuration
const API_BASE_URL = 'http://192.168.1.34:8000'; // Backend server on local network
const BACKEND_TIMEOUT = 30000; // 30 seconds

interface PhotoUploadData {
  userId: string;
  carModel: string;
  photoIndex: number;
  imageData: string;
  angle: number;
  framing: number;
  lighting: number;
  quality: number;
}

// ✅ Request OTP for authentication
export async function requestOTP(phone: string) {
  try {
    console.log('📞 Requesting OTP for:', phone);
    const formData = new FormData();
    formData.append('phone', phone);

    const response = await fetch(`${API_BASE_URL}/auth/request-otp`, {
      method: 'POST',
      body: formData,
      timeout: BACKEND_TIMEOUT,
    });

    if (!response.ok) {
      throw new Error(`OTP request failed: ${response.status}`);
    }

    const data = await response.json();
    console.log('✅ OTP sent successfully');
    return data;
  } catch (error) {
    console.error('❌ Error requesting OTP:', error);
    throw error;
  }
}

// ✅ Verify OTP and get user ID
export async function verifyOTP(phone: string, otp: number) {
  try {
    console.log('🔐 Verifying OTP for:', phone);
    const formData = new FormData();
    formData.append('phone', phone);
    formData.append('otp', otp.toString());

    const response = await fetch(`${API_BASE_URL}/auth/verify-otp`, {
      method: 'POST',
      body: formData,
      timeout: BACKEND_TIMEOUT,
    });

    if (!response.ok) {
      throw new Error(`OTP verification failed: ${response.status}`);
    }

    const data = await response.json();
    console.log('✅ OTP verified. User ID:', data.user_id);
    return data;
  } catch (error) {
    console.error('❌ Error verifying OTP:', error);
    throw error;
  }
}

// ✅ Start inspection session
export async function startInspection(userId: number) {
  try {
    console.log('🚗 Starting inspection for user:', userId);
    const formData = new FormData();
    formData.append('user_id', userId.toString());

    const response = await fetch(`${API_BASE_URL}/inspection/start`, {
      method: 'POST',
      body: formData,
      timeout: BACKEND_TIMEOUT,
    });

    if (!response.ok) {
      throw new Error(`Inspection start failed: ${response.status}`);
    }

    const data = await response.json();
    console.log('✅ Inspection started. ID:', data.inspection_id);
    return data;
  } catch (error) {
    console.error('❌ Error starting inspection:', error);
    throw error;
  }
}

// ✅ Upload image to backend
export async function uploadImage(
  inspectionId: number,
  imageType: string,
  imageUri: string
) {
  try {
    console.log('📤 Uploading image:', imageType);
    
    // Read file from URI
    const fileData = await FileSystem.readAsStringAsync(imageUri, {
      encoding: FileSystem.EncodingType.Base64,
    });

    const formData = new FormData();
    formData.append('inspection_id', inspectionId.toString());
    formData.append('image_type', imageType);
    formData.append('file', {
      uri: imageUri,
      type: 'image/jpeg',
      name: `${imageType}.jpg`,
    } as any);

    const response = await fetch(`${API_BASE_URL}/inspection/upload-image`, {
      method: 'POST',
      body: formData,
      timeout: BACKEND_TIMEOUT,
    });

    if (!response.ok) {
      throw new Error(`Image upload failed: ${response.status}`);
    }

    const data = await response.json();
    console.log('✅ Image uploaded. Similarity:', data.similarity);
    return data;
  } catch (error) {
    console.error('❌ Error uploading image:', error);
    throw error;
  }
}

export async function submitPhotos(userId: string, carModel: string, photoIds: string[]) {
  try {
    const response = await fetch(`${API_BASE_URL}/submissions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userId,
        carModel,
        photoIds,
      }),
    });

    if (!response.ok) {
      throw new Error(`Submission failed: ${response.status}`);
    }

    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Submission error:', error);
    throw error;
  }
}

export async function deletePhoto(photoId: string) {
  try {
    const response = await fetch(`${API_BASE_URL}/photos/${photoId}`, {
      method: 'DELETE',
    });

    if (!response.ok) {
      throw new Error(`Delete failed: ${response.status}`);
    }

    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Delete error:', error);
    throw error;
  }
}

// Convert image file to base64
export async function imageToBase64(imageUri: string): Promise<string> {
  try {
    const base64 = await (FileSystem as any).readAsStringAsync(imageUri, {
      encoding: (FileSystem as any).EncodingType.Base64,
    });
    return base64;
  } catch (error) {
    console.error('Base64 conversion error:', error);
    throw error;
  }
}
