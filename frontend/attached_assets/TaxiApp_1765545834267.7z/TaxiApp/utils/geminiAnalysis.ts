import * as FileSystem from 'expo-file-system';

// Gemini AI integration
// Get your free API key at: https://aistudio.google.com/apikey

export const GEMINI_API_KEY = 'AIzaSyCvCSP7Tad18kzwGrSmecZyQxr3qfJoGJc';

// For testing/demo mode - comment out after adding real API key
const USE_DEMO_MODE = false; // Set to true to test without real API key

export interface GeminiAnalysisResult {
  hasDamage: boolean;
  damageType: string;
  severity: 'none' | 'minor' | 'moderate' | 'severe';
  description: string;
  recommendations: string[];
  imageComplete: boolean;
  completenessNote?: string;
}

/**
 * Convert image file to base64 string for Gemini API
 */
async function imageToBase64(imageUri: string): Promise<string> {
  try {
    console.log('📸 Converting image to base64:', imageUri);

    // Read file as base64
    const base64 = await FileSystem.readAsStringAsync(imageUri, {
      encoding: 'base64',
    });

    if (!base64 || base64.length === 0) {
      throw new Error('Image conversion returned empty result');
    }

    console.log('✅ Image converted to base64, length:', base64.length);
    return base64;
  } catch (error) {
    console.error('❌ Error converting image to base64:', error);
    throw new Error(`Failed to process image: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Analyze car image using Google Gemini AI for damage detection
 * @param imageUri - URI of the car image to analyze
 * @returns Analysis result with damage information
 */
export async function analyzeCarDamageWithGemini(imageUri: string): Promise<GeminiAnalysisResult> {
  try {
    // Validate API key is set
    if (!GEMINI_API_KEY || GEMINI_API_KEY.includes('YOUR_GOOGLE_API_KEY')) {
      console.error('❌ Gemini API key not configured.');
      throw new Error(
        'Gemini API key not configured.'
      );
    }

    // Demo mode for testing without real API
    if (USE_DEMO_MODE) {
      console.log('🧪 DEMO MODE - Returning simulated analysis');

      const hasDamage = Math.random() < 0.5;

      const mockDamageTypes = [
        'Minor dents on front bumper',
        'Scratches on door panel',
        'Crease on fender',
        'Impact damage on hood',
        'Side mirror damage',
      ];

      const mockSeverities: Array<'none' | 'minor' | 'moderate' | 'severe'> = ['none', 'minor', 'moderate', 'severe'];

      return {
        hasDamage: hasDamage,
        damageType: hasDamage ? mockDamageTypes[Math.floor(Math.random() * mockDamageTypes.length)] : 'None',
        severity: hasDamage ? mockSeverities[Math.floor(Math.random() * (mockSeverities.length - 1)) + 1] : 'none',
        description: hasDamage
          ? `Simulated damage detected: ${Math.random() > 0.5 ? 'Visible dents' : 'Surface damage'} found during inspection`
          : 'Simulated analysis: No visible damage detected. Vehicle appears to be in good condition.',
        recommendations: hasDamage
          ? ['Get professional inspection', 'Check insurance coverage', 'Document damage with photos']
          : ['Regular maintenance recommended', 'Keep protective coating updated'],
        imageComplete: true,
      };
    }

    console.log('🔍 Analyzing car image with Gemini AI...');
    console.log('🔑 Using configured API Key');

    // Convert image to base64
    const base64 = await imageToBase64(imageUri);

    // Prepare the payload for Gemini API
    const payload = {
      contents: [
        {
          parts: [
            {
              text: `You are a professional car damage assessment expert. Analyze this car image and:
1. Identify if there are any visible dents, scratches, dents, or damage
2. Rate the severity (none, minor, moderate, severe)
3. Describe the specific damage location and type
4. Check if the image shows the complete car view or is incomplete

Respond in this exact JSON format (ONLY JSON, no other text):
{
  "hasDamage": boolean,
  "damageType": "description of damage types found",
  "severity": "none|minor|moderate|severe",
  "description": "detailed description of damage",
  "recommendations": ["recommendation 1", "recommendation 2"],
  "imageComplete": true|false,
  "completenessNote": "if incomplete, explain what's missing"
}

If image is completely blank or corrupted, set hasDamage to false and imageComplete to false.`,
            },
            {
              inline_data: {
                mime_type: 'image/jpeg',
                data: base64,
              },
            },
          ],
        },
      ],
    };

    // Call Gemini API with correct endpoint
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`;
    console.log('📡 Calling Gemini API (gemini-2.0-flash)...');

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error('❌ API Error:', response.status, errorData);
      throw new Error(`Gemini API request failed with status ${response.status}`);
    }

    const data = await response.json();

    // Extract the response text
    if (!data.candidates || !data.candidates[0] || !data.candidates[0].content) {
      throw new Error('Invalid response format from Gemini API');
    }

    const responseText = data.candidates[0].content.parts[0].text;
    console.log('📊 Raw AI Response:', responseText);

    // Clean up markdown formatting if present (remove ```json and ```)
    let cleanedText = responseText;
    if (cleanedText.includes('```')) {
      cleanedText = cleanedText
        .replace(/```json\n?/g, '')
        .replace(/```\n?/g, '')
        .trim();
    }

    // Parse the JSON response
    const analysisResult = JSON.parse(cleanedText);

    console.log('✅ Analysis Complete:', analysisResult);

    return analysisResult as GeminiAnalysisResult;
  } catch (error) {
    console.error('❌ Analysis error:', error);
    throw error;
  }
}

/**
 * Batch analyze multiple car images
 */
export async function analyzeBatchCarDamage(imageUris: string[]): Promise<GeminiAnalysisResult[]> {
  const results: GeminiAnalysisResult[] = [];

  for (let i = 0; i < imageUris.length; i++) {
    try {
      console.log(`🔄 Analyzing image ${i + 1}/${imageUris.length}...`);
      const result = await analyzeCarDamageWithGemini(imageUris[i]);
      results.push(result);

      // Add delay between requests to avoid rate limiting
      if (i < imageUris.length - 1) {
        await new Promise((resolve) => setTimeout(resolve, 1000));
      }
    } catch (error) {
      console.error(`❌ Failed to analyze image ${i + 1}:`, error);
      // Continue with next image on error
    }
  }

  return results;
}

/**
 * Generate damage report summary
 */
export function generateDamageReport(results: GeminiAnalysisResult[]): {
  totalImages: number;
  damageCount: number;
  averageSeverity: string;
  summary: string;
} {
  const totalImages = results.length;
  const damageCount = results.filter((r) => r.hasDamage).length;
  const severities = results
    .filter((r) => r.hasDamage)
    .map((r) => r.severity);

  const severityOrder = { none: 0, minor: 1, moderate: 2, severe: 3 };
  const averageSeverity =
    severities.length > 0
      ? Object.keys(severityOrder).find(
        (k) =>
          severityOrder[k as keyof typeof severityOrder] ===
          Math.round(
            severities.reduce((sum, s) => sum + severityOrder[s as keyof typeof severityOrder], 0) /
            severities.length
          )
      ) || 'minor'
      : 'none';

  const summary =
    damageCount === 0
      ? '✅ No damage detected in any photos'
      : `⚠️ Damage detected in ${damageCount}/${totalImages} photos. Average severity: ${averageSeverity}`;

  return {
    totalImages,
    damageCount,
    averageSeverity,
    summary,
  };
}
